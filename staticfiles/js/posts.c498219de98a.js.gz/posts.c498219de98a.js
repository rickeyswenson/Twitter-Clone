/////////
///JavaScriipt for menu function///*/


$(function() {
    //Toggle switch for Delete button
    $('.js-menu-icon').click(function() {
        $(this).next().toggle();
    })
})





